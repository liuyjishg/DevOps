zuul
====

Zuul is an edge service that provides dynamic routing, monitoring, resiliency, security, and more.
Please view the wiki for usage, information, HOWTO, etc https://github.com/Netflix/zuul/wiki
